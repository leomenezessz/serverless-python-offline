import uuid


def random_uuid4():
    return str(uuid.uuid4())
